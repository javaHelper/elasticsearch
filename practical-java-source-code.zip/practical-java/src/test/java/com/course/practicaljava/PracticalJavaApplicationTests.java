package com.course.practicaljava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticalJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
